import java.util.ArrayList;

public class Main
{
	public static void main(String[] args) 
	{
		Sort object = new Sort();
		 Integer array[]  = {10, 5, 7, 1, 3, 11, 2};
		  Integer array2[]  = {10, 5, 7, 1, 3, 11, 2};
		  Integer array3[]  = {10, 5, 7, 1, 3, 11, 2};
		  
		  object.insertionSort(array);//wrong  
		  
		 
	}

}
