
public class Search 
{
	
	//Linear Search or Sequential Search
	//No sorting
	public int linearSearch(Object array[], 
			Object o)
	{
		for(int i = 0; i < array.length; i++)
		{
			//if(array[i] == o) 
			//Use == for primitives and .equals() for objects
			
			if(array[i].equals(o))
			{
				return i;
			}
		}
		
		return -1;
		
	}
	
	//Binary Search
	//Pre-condition - array is already sorted

	
	//Loop
	public int binarySearch(Object array[], Object target)
	{
		int foundIndex = -1;
		Comparable theTarget = (Comparable)target;
		
		int high = array.length - 1;
		int low = 0;
		int middle = (low + high)/2;
		
		while(middle < high)
		{
			Comparable c = (Comparable)array[middle];
			if(theTarget.compareTo(c) == 0) //Found
			{
				return middle;
			}
			else if(theTarget.compareTo(c) < 0) //Left
			{
				  high = middle ;
				  middle = (low + high)/2;
			}
			else //Right
			{
				  low = middle;
				  middle = (low + high) / 2;
			}
			
			
		}
		
		return foundIndex;
		
	}
	
	//Recursive
	public int binarySearchRecursiveHelper(Object array[], Object target, int low, int high)
	{
		
         Comparable theTarget = (Comparable)target;
         int middle = (low + high) / 2;
         Comparable c  =(Comparable)array[middle];
         if(theTarget.compareTo(c) == 0)
         {
        	    return middle;
         }
         else if(low == high)
         {
        	    return -1;
         }
         else if(theTarget.compareTo(c) < 0) //Left
         {
        	     return binarySearchRecursiveHelper(array, target, low, middle);
         }
         else //Right
         {
    	             return binarySearchRecursiveHelper(array, target, middle, high);

         }
	}
	
	public int binarySearchRecursive(Object array[], Object target)
	{
		 return binarySearchRecursiveHelper(array, target, 0, array.length - 1);
	}
	

}
